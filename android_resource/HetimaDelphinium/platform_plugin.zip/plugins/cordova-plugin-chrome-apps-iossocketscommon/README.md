# chrome.socket Plugin

This plugin provides common services for chrome.socket and chrome.sockets APIs on iOS.

## Status

Beta on iOS. Unused on Android

## Notes

* This plugin is only used as a dependency for other plugins. It is probably not useful on its own.

# Release Notes

## 1.0.2 (April 30, 2015)
- Renamed plugin to pubilsh to NPM

## 1.0.1 (October 21, 2014)
- Changed plugin id to be compatible with Cordova plugman

## 1.0.0 (October 21, 2014)
- Initial release
