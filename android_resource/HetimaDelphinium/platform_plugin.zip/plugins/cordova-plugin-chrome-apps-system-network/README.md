# chrome.system.network Plugin

This plugin provides the ability to retrieve information about local network adapters.

## Status

Stable on Android and iOS.

## Reference

The API reference is [here](https://developer.chrome.com/apps/system_network).

# Release Notes

## 1.1.2 (April 30, 2015)
- Renamed plugin to pubilsh to NPM

## 1.1.1 (October 24, 2014)
* Fixed Xcode build error

## 1.1.0 (October 21, 2014)
* Added support for iOS

## 1.0.0
* Initial release
