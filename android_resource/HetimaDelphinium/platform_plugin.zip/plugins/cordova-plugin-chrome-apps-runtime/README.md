# chrome.runtime plugin

Implements the `chrome.runtime` and `chrome.app.runtime` namespaces.

# Release Notes

## 1.1.1 (April 30, 2015)
- Renamed plugin to pubilsh to NPM

## 1.1.0 (Mar 17, 2015)
* Parse manifest via JSON.parse for CSP-complaince

## 1.0.4 (Jan 27, 2015)
* Fix getURL when running in Cordova (fixes #487)
* Correctly handle missing manifest.json (Fixes #486)

## 1.0.3 (October 21, 2014)
- Documentation updates.

## 1.0.2 (August 21, 2014)
