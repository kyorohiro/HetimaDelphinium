# Chrome App Navigation override

This plugin contains the code used to intercept navigation within a Chrome app,
and open links in the system browser instead.

# Release Notes

## 1.0.3 (April 30, 2015)
- Renamed plugin to pubilsh to NPM

## 1.0.2 (October 21, 2014)
- Documentation updates.

## 1.0.1 (March 10, 2014)
- Fixes #76 - Don't detect hash changes as page reloads.
